This is a (modestly) improved version of the Sokoban sprite editor created by Golan Parashi.
This version allows to click and drag improving the user experience when painting. 

[Click here to use it!](https://rawgit.com/idelvall/nand-mines/master/tools/BitmapEditor/BitmapEditor.html)
